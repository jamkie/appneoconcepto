-- Drop existing RESTRICTIVE policies on sellers table
DROP POLICY IF EXISTS "Admins can manage sellers" ON public.sellers;
DROP POLICY IF EXISTS "Sellers can view their own record" ON public.sellers;

-- Create PERMISSIVE policy for admins to manage all sellers (SELECT, INSERT, UPDATE, DELETE)
CREATE POLICY "Admins can manage sellers"
ON public.sellers
FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Create PERMISSIVE policy for sellers to view their own record
CREATE POLICY "Sellers can view their own record"
ON public.sellers
FOR SELECT
TO authenticated
USING (user_id = auth.uid());

-- Ensure RLS is enabled (should already be enabled)
ALTER TABLE public.sellers ENABLE ROW LEVEL SECURITY;

-- Force RLS for table owner as well (additional security)
ALTER TABLE public.sellers FORCE ROW LEVEL SECURITY;