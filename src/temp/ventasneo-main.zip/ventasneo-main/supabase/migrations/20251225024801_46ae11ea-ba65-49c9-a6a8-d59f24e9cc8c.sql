-- Drop existing restrictive policies and recreate as permissive
-- For sales table
DROP POLICY IF EXISTS "Admins can manage sales" ON public.sales;
DROP POLICY IF EXISTS "Sellers can view their sales" ON public.sales;

-- Recreate as permissive policies (OR logic)
CREATE POLICY "Admins can manage sales"
ON public.sales
FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Sellers can view their sales"
ON public.sales
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1
    FROM sale_commissions sc
    JOIN sellers s ON sc.seller_id = s.id
    WHERE sc.sale_id = sales.id
    AND s.user_id = auth.uid()
  )
);

-- For sale_commissions table
DROP POLICY IF EXISTS "Admins can manage commissions" ON public.sale_commissions;
DROP POLICY IF EXISTS "Sellers can view their commissions" ON public.sale_commissions;

CREATE POLICY "Admins can manage commissions"
ON public.sale_commissions
FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Sellers can view their commissions"
ON public.sale_commissions
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1
    FROM sellers s
    WHERE s.id = sale_commissions.seller_id
    AND s.user_id = auth.uid()
  )
);

-- For payments table
DROP POLICY IF EXISTS "Admins can manage payments" ON public.payments;
DROP POLICY IF EXISTS "Sellers can view their payments" ON public.payments;

CREATE POLICY "Admins can manage payments"
ON public.payments
FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Sellers can view their payments"
ON public.payments
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1
    FROM sellers s
    WHERE s.id = payments.seller_id
    AND s.user_id = auth.uid()
  )
);

-- For sellers table
DROP POLICY IF EXISTS "Admins can manage sellers" ON public.sellers;
DROP POLICY IF EXISTS "Sellers can view their own record" ON public.sellers;

CREATE POLICY "Admins can manage sellers"
ON public.sellers
FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Sellers can view their own record"
ON public.sellers
FOR SELECT
TO authenticated
USING (user_id = auth.uid());