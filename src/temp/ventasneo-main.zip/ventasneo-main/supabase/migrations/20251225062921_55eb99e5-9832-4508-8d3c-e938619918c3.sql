-- Drop the overly permissive policy that exposes seller emails to all authenticated users
DROP POLICY IF EXISTS "Authenticated users can view sellers" ON public.sellers;

-- The remaining policies are sufficient:
-- "Admins can manage sellers" - admins can see all sellers
-- "Sellers can view their own record" - sellers can only see their own record