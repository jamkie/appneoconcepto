-- Fix infinite recursion in sale_commissions RLS policies by avoiding queries that hit sales RLS
-- Use a SECURITY DEFINER function to check sale ownership.

CREATE OR REPLACE FUNCTION public.is_sale_owner(_sale_id uuid, _user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.sales s
    WHERE s.id = _sale_id
      AND s.created_by = _user_id
  );
$$;

-- Recreate seller commission management policies to use the function (prevents recursion)
DROP POLICY IF EXISTS "Sellers can create commissions on their sales" ON public.sale_commissions;
CREATE POLICY "Sellers can create commissions on their sales"
ON public.sale_commissions
FOR INSERT
TO authenticated
WITH CHECK (public.is_sale_owner(sale_id, auth.uid()));

DROP POLICY IF EXISTS "Sellers can update commissions on their sales" ON public.sale_commissions;
CREATE POLICY "Sellers can update commissions on their sales"
ON public.sale_commissions
FOR UPDATE
TO authenticated
USING (public.is_sale_owner(sale_id, auth.uid()))
WITH CHECK (public.is_sale_owner(sale_id, auth.uid()));

DROP POLICY IF EXISTS "Sellers can delete commissions on their sales" ON public.sale_commissions;
CREATE POLICY "Sellers can delete commissions on their sales"
ON public.sale_commissions
FOR DELETE
TO authenticated
USING (public.is_sale_owner(sale_id, auth.uid()));
