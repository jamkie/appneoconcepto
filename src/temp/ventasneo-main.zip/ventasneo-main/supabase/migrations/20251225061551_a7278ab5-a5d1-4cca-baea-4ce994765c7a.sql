-- Allow sellers to create sales reliably and avoid issues when returning rows after insert
-- 1) Ensure created_by is always set for non-admins
-- 2) Relax INSERT check to require authenticated seller/admin (not strict created_by equality)
-- 3) Allow sellers to SELECT sales they created (so INSERT ... RETURNING works before commissions are inserted)

CREATE OR REPLACE FUNCTION public.set_sales_created_by()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Admins may set created_by explicitly (optional). Everyone else is forced to self.
  IF public.has_role(auth.uid(), 'admin'::public.app_role) AND NEW.created_by IS NOT NULL THEN
    RETURN NEW;
  END IF;

  NEW.created_by := auth.uid();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS sales_set_created_by ON public.sales;
CREATE TRIGGER sales_set_created_by
BEFORE INSERT ON public.sales
FOR EACH ROW
EXECUTE FUNCTION public.set_sales_created_by();

-- Update INSERT policy so sellers/admins can create, and created_by will be enforced by trigger.
DROP POLICY IF EXISTS "Sellers can create sales" ON public.sales;
CREATE POLICY "Sellers can create sales"
ON public.sales
FOR INSERT
TO authenticated
WITH CHECK (
  public.has_role(auth.uid(), 'admin'::public.app_role)
  OR EXISTS (
    SELECT 1
    FROM public.sellers s
    WHERE s.user_id = auth.uid()
  )
);

-- Ensure creators can read their newly created sale immediately (needed for INSERT ... RETURNING)
DROP POLICY IF EXISTS "Sellers can view sales they created" ON public.sales;
CREATE POLICY "Sellers can view sales they created"
ON public.sales
FOR SELECT
TO authenticated
USING (created_by = auth.uid());
