-- Fix RLS policy composition: existing admin ALL policies were created as RESTRICTIVE, which blocks seller policies.
-- Recreate admin policies as PERMISSIVE so seller policies can grant access.

-- SALES
DROP POLICY IF EXISTS "Admins can manage sales" ON public.sales;
CREATE POLICY "Admins can manage sales"
ON public.sales
FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::public.app_role))
WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));

-- SALE COMMISSIONS
DROP POLICY IF EXISTS "Admins can manage commissions" ON public.sale_commissions;
CREATE POLICY "Admins can manage commissions"
ON public.sale_commissions
FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::public.app_role))
WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));

-- PAYMENTS
DROP POLICY IF EXISTS "Admins can manage payments" ON public.payments;
CREATE POLICY "Admins can manage payments"
ON public.payments
FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::public.app_role))
WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));

-- SELLERS (ensure sellers list is visible to authenticated users so they can assign commissions)
DROP POLICY IF EXISTS "Authenticated users can view sellers" ON public.sellers;
CREATE POLICY "Authenticated users can view sellers"
ON public.sellers
FOR SELECT
TO authenticated
USING (true);

-- Keep (and make) own-record visibility permissive as well
DROP POLICY IF EXISTS "Sellers can view their own record" ON public.sellers;
CREATE POLICY "Sellers can view their own record"
ON public.sellers
FOR SELECT
TO authenticated
USING (user_id = auth.uid());
