-- Allow sellers to view all sellers (needed to assign commissions to others)
CREATE POLICY "Authenticated users can view sellers"
ON public.sellers
FOR SELECT
TO authenticated
USING (true);

-- Allow sellers to INSERT their own sales
CREATE POLICY "Sellers can create sales"
ON public.sales
FOR INSERT
TO authenticated
WITH CHECK (created_by = auth.uid());

-- Allow sellers to UPDATE their own sales
CREATE POLICY "Sellers can update their own sales"
ON public.sales
FOR UPDATE
TO authenticated
USING (created_by = auth.uid())
WITH CHECK (created_by = auth.uid());

-- Allow sellers to DELETE their own sales
CREATE POLICY "Sellers can delete their own sales"
ON public.sales
FOR DELETE
TO authenticated
USING (created_by = auth.uid());

-- Allow sellers to INSERT commissions on sales they created
CREATE POLICY "Sellers can create commissions on their sales"
ON public.sale_commissions
FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM sales s
    WHERE s.id = sale_id AND s.created_by = auth.uid()
  )
);

-- Allow sellers to UPDATE commissions on sales they created
CREATE POLICY "Sellers can update commissions on their sales"
ON public.sale_commissions
FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM sales s
    WHERE s.id = sale_id AND s.created_by = auth.uid()
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM sales s
    WHERE s.id = sale_id AND s.created_by = auth.uid()
  )
);

-- Allow sellers to DELETE commissions on sales they created
CREATE POLICY "Sellers can delete commissions on their sales"
ON public.sale_commissions
FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM sales s
    WHERE s.id = sale_id AND s.created_by = auth.uid()
  )
);