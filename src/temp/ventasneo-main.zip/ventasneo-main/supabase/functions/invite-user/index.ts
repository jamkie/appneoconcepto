import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";
import { Resend } from "https://esm.sh/resend@2.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface InviteUserRequest {
  email: string;
  name: string;
  role: "admin" | "user";
  createSeller: boolean;
  password?: string; // Optional: if provided, user is created with this password (no email sent)
}

serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Get the authorization header
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      console.error("No authorization header provided");
      return new Response(
        JSON.stringify({ error: "No authorization header" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create a Supabase client with the service role key for admin operations
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false,
        },
      }
    );

    // Extract the token from the Authorization header
    const token = authHeader.replace(/^Bearer\s+/i, "").trim();
    if (!token) {
      console.error("Authorization header present but token is empty");
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create a client to verify the user's token
    const supabaseUser = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false,
        },
      }
    );

    // Get the current user using the token explicitly
    const { data: { user: currentUser }, error: userError } = await supabaseUser.auth.getUser(token);
    if (userError || !currentUser) {
      console.error("Error getting current user:", userError);
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Verify the current user is an admin
    const { data: roleData, error: roleError } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", currentUser.id)
      .eq("role", "admin")
      .maybeSingle();

    if (roleError || !roleData) {
      console.error("User is not an admin:", roleError);
      return new Response(
        JSON.stringify({ error: "Solo los administradores pueden invitar usuarios" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Parse the request body
    const { email, name, role, createSeller, password }: InviteUserRequest = await req.json();

    if (!email || !name || !role) {
      return new Response(
        JSON.stringify({ error: "Email, nombre y rol son requeridos" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`Inviting user: ${email} with role: ${role}, createSeller: ${createSeller}, hasPassword: ${!!password}`);

    // Use provided password or generate a temporary one
    const userPassword = password || crypto.randomUUID().slice(0, 16);
    const passwordProvided = !!password;

    // Create the user using admin API
    const { data: newUser, error: createError } = await supabaseAdmin.auth.admin.createUser({
      email,
      password: userPassword,
      email_confirm: true,
      user_metadata: {
        name,
      },
    });

    if (createError) {
      console.error("Error creating user:", createError);
      return new Response(
        JSON.stringify({ error: createError.message }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`User created successfully: ${newUser.user.id}`);

    // Update the user role if admin
    if (role === "admin") {
      const { error: updateRoleError } = await supabaseAdmin
        .from("user_roles")
        .update({ role: "admin" })
        .eq("user_id", newUser.user.id);

      if (updateRoleError) {
        console.error("Error updating role:", updateRoleError);
      } else {
        console.log(`User role updated to admin`);
      }
    }

    // Create seller record if requested
    let sellerId = null;
    if (createSeller) {
      const { data: sellerData, error: sellerError } = await supabaseAdmin
        .from("sellers")
        .insert({
          name,
          email,
          user_id: newUser.user.id,
        })
        .select()
        .single();

      if (sellerError) {
        console.error("Error creating seller:", sellerError);
      } else {
        sellerId = sellerData.id;
        console.log(`Seller created: ${sellerId}`);
      }
    }

    // If password was provided by admin, skip email and return success
    if (passwordProvided) {
      console.log(`Password provided by admin, skipping email invitation`);
      return new Response(
        JSON.stringify({
          success: true,
          user: {
            id: newUser.user.id,
            email: newUser.user.email,
            name,
            role,
          },
          sellerId,
          emailSent: false,
          passwordSet: true,
          message: "Usuario creado exitosamente con la contraseña proporcionada.",
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Generate password reset link with redirect to reset-password page
    const siteUrl = req.headers.get("origin") || "https://ventasneo.lovable.app";
    const { data: resetData, error: resetError } = await supabaseAdmin.auth.admin.generateLink({
      type: "recovery",
      email,
      options: {
        redirectTo: `${siteUrl}/reset-password`,
      },
    });

    if (resetError) {
      console.error("Error generating reset link:", resetError);
    }

    // Send invitation email using Resend
    const resendApiKey = Deno.env.get("RESEND_API_KEY");
    if (resendApiKey && resetData?.properties?.action_link) {
      const resend = new Resend(resendApiKey);
      
      const roleText = role === "admin" ? "Administrador" : "Vendedor";
      // Modify the action link to include the redirect
      const originalLink = resetData.properties.action_link;
      const resetLink = originalLink.includes("redirect_to") 
        ? originalLink 
        : `${originalLink}&redirect_to=${encodeURIComponent(`${siteUrl}/reset-password`)}`;
      
      console.log(`Sending invitation email to ${email}`);
      
      try {
        const emailResult = await resend.emails.send({
          from: "Sistema de Ventas <noreply@neoconcepto.com>",
          to: [email],
          subject: "Invitación al Sistema de Ventas",
          html: `
            <!DOCTYPE html>
            <html>
              <head>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
              </head>
              <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; margin: 0; padding: 0; background-color: #f4f4f5;">
                <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f4f4f5; padding: 40px 20px;">
                  <tr>
                    <td align="center">
                      <table width="100%" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
                        <tr>
                          <td style="background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%); padding: 40px 20px; text-align: center;">
                            <h1 style="color: #ffffff; margin: 0; font-size: 28px; font-weight: 700;">¡Bienvenido/a!</h1>
                          </td>
                        </tr>
                        <tr>
                          <td style="padding: 40px 30px;">
                            <p style="color: #374151; font-size: 16px; line-height: 1.6; margin: 0 0 20px;">
                              Hola <strong>${name}</strong>,
                            </p>
                            <p style="color: #374151; font-size: 16px; line-height: 1.6; margin: 0 0 20px;">
                              Has sido invitado/a a unirte al Sistema de Ventas como <strong>${roleText}</strong>.
                            </p>
                            <p style="color: #374151; font-size: 16px; line-height: 1.6; margin: 0 0 30px;">
                              Para completar tu registro y establecer tu contraseña, haz clic en el siguiente botón:
                            </p>
                            <table width="100%" cellpadding="0" cellspacing="0">
                              <tr>
                                <td align="center">
                                  <a href="${resetLink}" style="display: inline-block; background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%); color: #ffffff; text-decoration: none; padding: 14px 32px; border-radius: 8px; font-size: 16px; font-weight: 600;">
                                    Establecer mi contraseña
                                  </a>
                                </td>
                              </tr>
                            </table>
                            <p style="color: #6b7280; font-size: 14px; line-height: 1.6; margin: 30px 0 0; text-align: center;">
                              Este enlace expirará en 24 horas.
                            </p>
                          </td>
                        </tr>
                        <tr>
                          <td style="background-color: #f9fafb; padding: 20px 30px; text-align: center; border-top: 1px solid #e5e7eb;">
                            <p style="color: #9ca3af; font-size: 12px; margin: 0;">
                              Si no esperabas este correo, puedes ignorarlo.
                            </p>
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                </table>
              </body>
            </html>
          `,
        });
        
        // Check if email was actually sent successfully
        if (emailResult.error) {
          console.error("Resend API error:", emailResult.error);
          // Return success but with email warning
          return new Response(
            JSON.stringify({
              success: true,
              user: {
                id: newUser.user.id,
                email: newUser.user.email,
                name,
                role,
              },
              sellerId,
              emailSent: false,
              emailError: emailResult.error.message,
              message: "Usuario creado, pero el email no pudo ser enviado. " + emailResult.error.message,
            }),
            { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        
        console.log("Email sent successfully:", emailResult.data);
      } catch (emailError: any) {
        console.error("Error sending email:", emailError);
        // Return success but with email warning
        return new Response(
          JSON.stringify({
            success: true,
            user: {
              id: newUser.user.id,
              email: newUser.user.email,
              name,
              role,
            },
            sellerId,
            emailSent: false,
            emailError: emailError.message,
            message: "Usuario creado, pero el email no pudo ser enviado.",
          }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    } else {
      console.log("Resend API key not configured or reset link not generated, skipping email");
    }

    return new Response(
      JSON.stringify({
        success: true,
        user: {
          id: newUser.user.id,
          email: newUser.user.email,
          name,
          role,
        },
        sellerId,
        emailSent: !!resendApiKey && !!resetData?.properties?.action_link,
        message: "Usuario creado exitosamente. Se ha enviado un email para que establezca su contraseña.",
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: any) {
    console.error("Error in invite-user function:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Error interno del servidor" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
