import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface ManageUserRequest {
  action: "update" | "delete" | "set-password";
  userId?: string;
  sellerId?: string;
  data?: {
    name?: string;
    email?: string;
    role?: "admin" | "user";
    password?: string;
  };
}

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      console.error("No authorization header provided");
      return new Response(
        JSON.stringify({ error: "No authorization header" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false,
        },
      }
    );

    const token = authHeader.replace(/^Bearer\s+/i, "").trim();
    if (!token) {
      console.error("Authorization header present but token is empty");
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUser = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false,
        },
      }
    );

    // IMPORTANT: In Edge Functions there is no persisted session storage.
    // We must pass the access token explicitly.
    const { data: { user: currentUser }, error: userError } = await supabaseUser.auth.getUser(token);
    if (userError || !currentUser) {
      console.error("Error getting current user:", userError);
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { data: roleData, error: roleError } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", currentUser.id)
      .eq("role", "admin")
      .maybeSingle();

    if (roleError || !roleData) {
      console.error("User is not an admin:", roleError);
      return new Response(
        JSON.stringify({ error: "Solo los administradores pueden gestionar usuarios" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { action, userId, sellerId, data }: ManageUserRequest = await req.json();

    console.log(`Managing user: action=${action}, userId=${userId}, sellerId=${sellerId}`);

    if (action === "update") {
      // Update seller record
      if (sellerId && data) {
        const updateData: any = {};
        if (data.name) updateData.name = data.name;
        if (data.email) updateData.email = data.email;

        if (Object.keys(updateData).length > 0) {
          const { error: sellerError } = await supabaseAdmin
            .from("sellers")
            .update(updateData)
            .eq("id", sellerId);

          if (sellerError) {
            console.error("Error updating seller:", sellerError);
            return new Response(
              JSON.stringify({ error: sellerError.message }),
              { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
            );
          }
          console.log(`Seller ${sellerId} updated`);
        }
      }

      // Update auth user if userId is provided
      if (userId && data) {
        const updateUserData: any = {};
        if (data.email) updateUserData.email = data.email;
        if (data.name) updateUserData.user_metadata = { name: data.name };

        if (Object.keys(updateUserData).length > 0) {
          const { error: authError } = await supabaseAdmin.auth.admin.updateUserById(
            userId,
            updateUserData
          );

          if (authError) {
            console.error("Error updating auth user:", authError);
            // Don't fail if auth update fails but seller was updated
          } else {
            console.log(`Auth user ${userId} updated`);
          }
        }

        // Update role if changed
        if (data.role) {
          const { error: roleUpdateError } = await supabaseAdmin
            .from("user_roles")
            .update({ role: data.role })
            .eq("user_id", userId);

          if (roleUpdateError) {
            console.error("Error updating role:", roleUpdateError);
          } else {
            console.log(`User role updated to ${data.role}`);
          }
        }
      }

      return new Response(
        JSON.stringify({ success: true, message: "Usuario actualizado exitosamente" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (action === "set-password") {
      if (!userId || !data?.password) {
        return new Response(
          JSON.stringify({ error: "userId y password son requeridos" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Validate password length
      if (data.password.length < 6) {
        return new Response(
          JSON.stringify({ error: "La contraseña debe tener al menos 6 caracteres" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      console.log(`Setting password for user ${userId}`);

      const { error: passwordError } = await supabaseAdmin.auth.admin.updateUserById(
        userId,
        { password: data.password }
      );

      if (passwordError) {
        console.error("Error setting password:", passwordError);
        return new Response(
          JSON.stringify({ error: passwordError.message }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      console.log(`Password set successfully for user ${userId}`);

      return new Response(
        JSON.stringify({ success: true, message: "Contraseña actualizada exitosamente" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (action === "delete") {
      // Prevent deleting yourself
      if (userId === currentUser.id) {
        return new Response(
          JSON.stringify({ error: "No puedes eliminar tu propia cuenta" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Delete seller record first (if exists)
      if (sellerId) {
        // Delete related payments first
        const { error: paymentsError } = await supabaseAdmin
          .from("payments")
          .delete()
          .eq("seller_id", sellerId);

        if (paymentsError) {
          console.error("Error deleting payments:", paymentsError);
        }

        // Delete related commissions
        const { error: commissionsError } = await supabaseAdmin
          .from("sale_commissions")
          .delete()
          .eq("seller_id", sellerId);

        if (commissionsError) {
          console.error("Error deleting commissions:", commissionsError);
        }

        // Delete seller
        const { error: sellerError } = await supabaseAdmin
          .from("sellers")
          .delete()
          .eq("id", sellerId);

        if (sellerError) {
          console.error("Error deleting seller:", sellerError);
          return new Response(
            JSON.stringify({ error: sellerError.message }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        console.log(`Seller ${sellerId} deleted`);
      }

      // Delete auth user if userId is provided
      if (userId) {
        // Delete user role first
        const { error: roleDeleteError } = await supabaseAdmin
          .from("user_roles")
          .delete()
          .eq("user_id", userId);

        if (roleDeleteError) {
          console.error("Error deleting user role:", roleDeleteError);
        }

        // Delete auth user
        const { error: authError } = await supabaseAdmin.auth.admin.deleteUser(userId);

        if (authError) {
          console.error("Error deleting auth user:", authError);
          // Don't fail completely if seller was deleted
        } else {
          console.log(`Auth user ${userId} deleted`);
        }
      }

      return new Response(
        JSON.stringify({ success: true, message: "Usuario eliminado exitosamente" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ error: "Acción no válida" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: any) {
    console.error("Error in manage-user function:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Error interno del servidor" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
