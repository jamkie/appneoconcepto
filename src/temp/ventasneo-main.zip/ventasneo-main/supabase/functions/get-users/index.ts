import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      console.error("No authorization header provided");
      return new Response(
        JSON.stringify({ error: "No authorization header" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Extract the token from the Authorization header
    const token = authHeader.replace(/^Bearer\s+/i, "").trim();
    if (!token) {
      console.error("Authorization header present but token is empty");
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create a Supabase client with the service role key for admin operations
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { autoRefreshToken: false, persistSession: false } }
    );

    // Create a client to verify the user's token
    const supabaseUser = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      { auth: { autoRefreshToken: false, persistSession: false } }
    );

    // Get the current user using the token explicitly
    const { data: { user: currentUser }, error: userError } = await supabaseUser.auth.getUser(token);
    
    if (userError) {
      console.error("Error getting current user:", userError);
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!currentUser) {
      console.error("No user found for token");
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("Current user:", currentUser.id, currentUser.email);

    // Verify admin
    const { data: roleData, error: roleError } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", currentUser.id)
      .eq("role", "admin")
      .maybeSingle();

    if (roleError) {
      console.error("Error checking role:", roleError);
    }

    if (!roleData) {
      console.error("User is not an admin:", currentUser.id);
      return new Response(
        JSON.stringify({ error: "Solo los administradores pueden ver usuarios" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("User is admin, fetching all users...");

    // Get all auth users
    const { data: authUsers, error: authError } = await supabaseAdmin.auth.admin.listUsers();
    if (authError) {
      console.error("Error listing users:", authError);
      throw authError;
    }

    console.log("Found", authUsers.users.length, "users");

    // Get roles
    const { data: rolesData } = await supabaseAdmin.from("user_roles").select("user_id, role");
    
    // Get sellers
    const { data: sellersData } = await supabaseAdmin.from("sellers").select("id, user_id, name, email");

    // Build user list with status
    const users = authUsers.users.map(authUser => {
      const role = rolesData?.find(r => r.user_id === authUser.id);
      const seller = sellersData?.find(s => s.user_id === authUser.id);
      
      // User is active if:
      // 1. They have the password_set flag in their metadata, OR
      // 2. They signed in with password method (existing users), OR
      // 3. Their last_sign_in_at is significantly after created_at (more than 5 minutes)
      const metadata = authUser.user_metadata || {};
      const hasPasswordSet = metadata.password_set === true;
      const createdAt = new Date(authUser.created_at).getTime();
      const lastSignIn = authUser.last_sign_in_at ? new Date(authUser.last_sign_in_at).getTime() : null;
      const signedInAfterCreation = lastSignIn && (lastSignIn - createdAt) > 5 * 60 * 1000; // 5 minutes
      
      const isActive = hasPasswordSet || signedInAfterCreation || (lastSignIn !== null && !authUser.email?.includes("@") === false && (lastSignIn - createdAt) > 60000);
      
      return {
        id: authUser.id,
        email: authUser.email || seller?.email || "",
        name: metadata.name || seller?.name || null,
        role: role?.role || "user",
        sellerId: seller?.id || null,
        sellerName: seller?.name || null,
        isActive: hasPasswordSet || signedInAfterCreation,
        lastSignIn: authUser.last_sign_in_at,
        createdAt: authUser.created_at,
      };
    });

    console.log("Returning", users.length, "users");

    return new Response(
      JSON.stringify({ users }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: any) {
    console.error("Error in get-users:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
