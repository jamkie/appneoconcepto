export interface Seller {
  id: string;
  name: string;
  email: string;
  totalCommissions: number;
  totalPaid: number;
  pendingBalance: number;
}

export interface SaleCommission {
  sellerId: string;
  sellerName: string;
  percentage: number;
  amount: number;
}

export interface Sale {
  id: string;
  projectName: string;
  clientName: string;
  date: string;
  totalWithVat: number;
  vat: number;
  totalWithoutVat: number;
  commissions: SaleCommission[];
}

export interface Payment {
  id: string;
  sellerId: string;
  sellerName: string;
  date: string;
  amount: number;
  concept: string;
}

export const mockSellers: Seller[] = [
  {
    id: "1",
    name: "Carlos Mendoza",
    email: "carlos@empresa.com",
    totalCommissions: 45000,
    totalPaid: 30000,
    pendingBalance: 15000,
  },
  {
    id: "2",
    name: "María García",
    email: "maria@empresa.com",
    totalCommissions: 62000,
    totalPaid: 50000,
    pendingBalance: 12000,
  },
  {
    id: "3",
    name: "Roberto López",
    email: "roberto@empresa.com",
    totalCommissions: 38000,
    totalPaid: 38000,
    pendingBalance: 0,
  },
];

export const mockSales: Sale[] = [
  {
    id: "1",
    projectName: "Desarrollo Web E-commerce",
    clientName: "Tienda Digital SA",
    date: "2024-01-15",
    totalWithVat: 232000,
    vat: 32000,
    totalWithoutVat: 200000,
    commissions: [
      { sellerId: "1", sellerName: "Carlos Mendoza", percentage: 5, amount: 10000 },
      { sellerId: "2", sellerName: "María García", percentage: 3, amount: 6000 },
    ],
  },
  {
    id: "2",
    projectName: "App Móvil Restaurantes",
    clientName: "Grupo Gastronómico",
    date: "2024-01-20",
    totalWithVat: 348000,
    vat: 48000,
    totalWithoutVat: 300000,
    commissions: [
      { sellerId: "2", sellerName: "María García", percentage: 4, amount: 12000 },
    ],
  },
  {
    id: "3",
    projectName: "Sistema de Inventarios",
    clientName: "Distribuidora Norte",
    date: "2024-02-01",
    totalWithVat: 174000,
    vat: 24000,
    totalWithoutVat: 150000,
    commissions: [
      { sellerId: "1", sellerName: "Carlos Mendoza", percentage: 6, amount: 9000 },
      { sellerId: "3", sellerName: "Roberto López", percentage: 4, amount: 6000 },
    ],
  },
  {
    id: "4",
    projectName: "Portal Corporativo",
    clientName: "Constructora ABC",
    date: "2024-02-10",
    totalWithVat: 116000,
    vat: 16000,
    totalWithoutVat: 100000,
    commissions: [
      { sellerId: "1", sellerName: "Carlos Mendoza", percentage: 5, amount: 5000 },
    ],
  },
];

export const mockPayments: Payment[] = [
  {
    id: "1",
    sellerId: "1",
    sellerName: "Carlos Mendoza",
    date: "2024-01-25",
    amount: 15000,
    concept: "Pago parcial comisiones enero",
  },
  {
    id: "2",
    sellerId: "1",
    sellerName: "Carlos Mendoza",
    date: "2024-02-05",
    amount: 15000,
    concept: "Pago comisiones pendientes",
  },
  {
    id: "3",
    sellerId: "2",
    sellerName: "María García",
    date: "2024-01-30",
    amount: 25000,
    concept: "Anticipo comisiones",
  },
  {
    id: "4",
    sellerId: "2",
    sellerName: "María García",
    date: "2024-02-10",
    amount: 25000,
    concept: "Liquidación enero",
  },
  {
    id: "5",
    sellerId: "3",
    sellerName: "Roberto López",
    date: "2024-02-15",
    amount: 38000,
    concept: "Liquidación total comisiones",
  },
];

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat("es-MX", {
    style: "currency",
    currency: "MXN",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
};

export const formatDate = (dateString: string): string => {
  return new Intl.DateTimeFormat("es-MX", {
    year: "numeric",
    month: "short",
    day: "numeric",
  }).format(new Date(dateString));
};
