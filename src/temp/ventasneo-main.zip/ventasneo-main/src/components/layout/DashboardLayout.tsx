import { ReactNode } from "react";
import { Sidebar } from "./Sidebar";
import { MobileNav } from "./MobileNav";
import { useIsMobile } from "@/hooks/use-mobile";

interface DashboardLayoutProps {
  children: ReactNode;
}

export function DashboardLayout({ children }: DashboardLayoutProps) {
  const isMobile = useIsMobile();

  return (
    <div className="min-h-screen bg-background">
      {isMobile ? (
        <>
          <MobileNav />
          <main className="min-h-screen p-4 pb-20">
            {children}
          </main>
        </>
      ) : (
        <>
          <Sidebar />
          <main className="ml-64 min-h-screen p-8 transition-all duration-300">
            {children}
          </main>
        </>
      )}
    </div>
  );
}
