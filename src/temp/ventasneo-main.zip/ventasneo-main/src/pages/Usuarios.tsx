import { useState, useEffect } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, UserPlus, Pencil, Trash2, Shield, User, Search, Mail, RefreshCw, Clock, CheckCircle, Key } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

interface UserWithRole {
  id: string;
  email: string;
  name: string | null;
  role: "admin" | "user";
  sellerId: string | null;
  sellerName: string | null;
  isActive: boolean;
  lastSignIn: string | null;
  createdAt: string;
}

export default function Usuarios() {
  const { user: currentUser } = useAuth();
  const [users, setUsers] = useState<UserWithRole[]>([]);
  const [loading, setLoading] = useState(true);
  const [isInviteOpen, setIsInviteOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [isPasswordOpen, setIsPasswordOpen] = useState(false);
  const [userToEdit, setUserToEdit] = useState<UserWithRole | null>(null);
  const [userToDelete, setUserToDelete] = useState<UserWithRole | null>(null);
  const [userToSetPassword, setUserToSetPassword] = useState<UserWithRole | null>(null);
  const [inviting, setInviting] = useState(false);
  const [updating, setUpdating] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [settingPassword, setSettingPassword] = useState(false);
  const [resendingInvitation, setResendingInvitation] = useState<string | null>(null);
  const [inviteResult, setInviteResult] = useState<{
    email: string;
    emailSent: boolean;
  } | null>(null);
  
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState<"all" | "admin" | "user">("all");

  const [newUser, setNewUser] = useState({
    name: "",
    email: "",
    password: "",
    role: "user" as "admin" | "user",
    createSeller: true, // Por defecto true porque el rol por defecto es "user" (vendedor)
  });

  const [newPassword, setNewPassword] = useState("");

  const [editData, setEditData] = useState({
    name: "",
    email: "",
    role: "user" as "admin" | "user",
  });

  const fetchUsers = async () => {
    try {
      const { data, error } = await supabase.functions.invoke("get-users");

      if (error) throw error;
      if (data.error) throw new Error(data.error);

      setUsers(data.users || []);
    } catch (error: any) {
      console.error("Error fetching users:", error);
      toast.error("Error al cargar los usuarios");
    } finally {
      setLoading(false);
    }
  };

  const handleResendInvitation = async (user: UserWithRole) => {
    setResendingInvitation(user.id);
    try {
      const { data, error } = await supabase.functions.invoke("resend-invitation", {
        body: {
          userId: user.id,
          email: user.email,
          name: user.name,
        },
      });

      if (error) throw error;
      if (data.error) {
        toast.error(`Error al reenviar: ${data.error}`);
      } else {
        toast.success("Invitación reenviada exitosamente");
      }
    } catch (error: any) {
      console.error("Error resending invitation:", error);
      toast.error(error.message || "Error al reenviar invitación");
    } finally {
      setResendingInvitation(null);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const resetInviteForm = () => {
    setNewUser({ name: "", email: "", password: "", role: "user", createSeller: true });
    setInviteResult(null);
  };

  const resetPasswordForm = () => {
    setNewPassword("");
    setUserToSetPassword(null);
  };

  const resetEditForm = () => {
    setEditData({ name: "", email: "", role: "user" });
    setUserToEdit(null);
  };

  const handleInviteUser = async () => {
    if (!newUser.name || !newUser.email) {
      toast.error("Por favor completa el nombre y email");
      return;
    }

    setInviting(true);
    try {
      const { data, error } = await supabase.functions.invoke("invite-user", {
        body: {
          email: newUser.email,
          name: newUser.name,
          role: newUser.role,
          createSeller: newUser.createSeller,
          password: newUser.password || undefined, // Only send if provided
        },
      });

      if (error) throw error;

      if (data.error) {
        throw new Error(data.error);
      }

      setInviteResult({
        email: newUser.email,
        emailSent: data.emailSent || false,
      });

      if (data.passwordSet) {
        toast.success("Usuario creado exitosamente con la contraseña proporcionada.");
      } else if (data.emailSent) {
        toast.success("Usuario invitado exitosamente. Se envió un email para establecer contraseña.");
      } else if (data.emailError) {
        toast.warning(`Usuario creado, pero el email no pudo ser enviado: ${data.emailError}`);
      } else {
        toast.success("Usuario creado exitosamente");
      }
      fetchUsers();
    } catch (error: any) {
      console.error("Error inviting user:", error);
      toast.error(error.message || "Error al invitar usuario");
    } finally {
      setInviting(false);
    }
  };

  const handleOpenEdit = (user: UserWithRole) => {
    setUserToEdit(user);
    setEditData({
      name: user.name || "",
      email: user.email,
      role: user.role,
    });
    setIsEditOpen(true);
  };

  const handleUpdateUser = async () => {
    if (!userToEdit) return;

    if (!editData.email) {
      toast.error("El email es requerido");
      return;
    }

    setUpdating(true);
    try {
      const { data, error } = await supabase.functions.invoke("manage-user", {
        body: {
          action: "update",
          userId: userToEdit.id,
          sellerId: userToEdit.sellerId,
          data: {
            name: editData.name,
            email: editData.email,
            role: editData.role,
          },
        },
      });

      if (error) throw error;

      if (data.error) {
        throw new Error(data.error);
      }

      toast.success("Usuario actualizado exitosamente");
      resetEditForm();
      setIsEditOpen(false);
      fetchUsers();
    } catch (error: any) {
      console.error("Error updating user:", error);
      toast.error(error.message || "Error al actualizar usuario");
    } finally {
      setUpdating(false);
    }
  };

  const handleDeleteUser = async () => {
    if (!userToDelete) return;

    if (userToDelete.id === currentUser?.id) {
      toast.error("No puedes eliminar tu propia cuenta");
      return;
    }

    setDeleting(true);
    try {
      const { data, error } = await supabase.functions.invoke("manage-user", {
        body: {
          action: "delete",
          userId: userToDelete.id,
          sellerId: userToDelete.sellerId,
        },
      });

      if (error) throw error;

      if (data.error) {
        throw new Error(data.error);
      }

      toast.success("Usuario eliminado exitosamente");
      setUserToDelete(null);
      setIsDeleteOpen(false);
      fetchUsers();
    } catch (error: any) {
      console.error("Error deleting user:", error);
      toast.error(error.message || "Error al eliminar usuario");
    } finally {
      setDeleting(false);
    }
  };

  const handleOpenSetPassword = (user: UserWithRole) => {
    setUserToSetPassword(user);
    setNewPassword("");
    setIsPasswordOpen(true);
  };

  const handleSetPassword = async () => {
    if (!userToSetPassword) return;

    if (!newPassword || newPassword.length < 6) {
      toast.error("La contraseña debe tener al menos 6 caracteres");
      return;
    }

    setSettingPassword(true);
    try {
      const { data, error } = await supabase.functions.invoke("manage-user", {
        body: {
          action: "set-password",
          userId: userToSetPassword.id,
          data: {
            password: newPassword,
          },
        },
      });

      if (error) throw error;

      if (data.error) {
        throw new Error(data.error);
      }

      toast.success("Contraseña actualizada exitosamente");
      resetPasswordForm();
      setIsPasswordOpen(false);
    } catch (error: any) {
      console.error("Error setting password:", error);
      toast.error(error.message || "Error al establecer contraseña");
    } finally {
      setSettingPassword(false);
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Usuarios</h1>
            <p className="text-muted-foreground">
              Gestiona los usuarios del sistema
            </p>
          </div>
          
          {/* Invite User Button */}
          <Dialog open={isInviteOpen} onOpenChange={(open) => {
            setIsInviteOpen(open);
            if (!open) resetInviteForm();
          }}>
            <DialogTrigger asChild>
              <Button variant="accent">
                <UserPlus className="mr-2 h-4 w-4" />
                Nuevo Usuario
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Invitar Nuevo Usuario</DialogTitle>
                <DialogDescription>
                  Crea una cuenta de acceso al sistema con email y contraseña.
                </DialogDescription>
              </DialogHeader>
              
              {inviteResult ? (
                <div className="py-4 space-y-4">
                  <div className="rounded-lg bg-success/10 border border-success/20 p-4">
                    <p className="font-medium text-success mb-2">¡Usuario creado exitosamente!</p>
                    {inviteResult.emailSent ? (
                      <>
                        <p className="text-sm text-muted-foreground mb-4">
                          Se ha enviado un email a <strong>{inviteResult.email}</strong> con un enlace para que establezca su contraseña.
                        </p>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Mail className="h-4 w-4" />
                          <span>El usuario recibirá instrucciones por correo</span>
                        </div>
                      </>
                    ) : (
                      <p className="text-sm text-muted-foreground">
                        El usuario ha sido creado. Por favor contacta al administrador para obtener las credenciales de acceso.
                      </p>
                    )}
                  </div>
                  <Button
                    variant="accent"
                    className="w-full"
                    onClick={() => {
                      resetInviteForm();
                      setIsInviteOpen(false);
                    }}
                  >
                    Cerrar
                  </Button>
                </div>
              ) : (
                <div className="grid gap-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="invite-name">Nombre Completo</Label>
                    <Input
                      id="invite-name"
                      placeholder="Nombre del usuario"
                      value={newUser.name}
                      onChange={(e) =>
                        setNewUser({ ...newUser, name: e.target.value })
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="invite-email">Correo Electrónico</Label>
                    <Input
                      id="invite-email"
                      type="email"
                      placeholder="correo@empresa.com"
                      value={newUser.email}
                      onChange={(e) =>
                        setNewUser({ ...newUser, email: e.target.value })
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Rol del Usuario</Label>
                    <Select
                      value={newUser.role}
                      onValueChange={(value: "admin" | "user") =>
                        setNewUser({ 
                          ...newUser, 
                          role: value,
                          // Si es vendedor, siempre crear como seller
                          createSeller: value === "user" ? true : newUser.createSeller 
                        })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="user">Vendedor</SelectItem>
                        <SelectItem value="admin">Administrador</SelectItem>
                      </SelectContent>
                    </Select>
                    {newUser.role === "user" && (
                      <p className="text-xs text-muted-foreground">
                        Se creará automáticamente como vendedor para asignarle comisiones.
                      </p>
                    )}
                  </div>
                  {newUser.role === "admin" && (
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="create-seller"
                        checked={newUser.createSeller}
                        onCheckedChange={(checked) =>
                          setNewUser({ ...newUser, createSeller: checked as boolean })
                        }
                      />
                      <Label htmlFor="create-seller" className="text-sm font-normal">
                        Crear también como vendedor (para asignar comisiones)
                      </Label>
                    </div>
                  )}
                  <div className="space-y-2">
                    <Label htmlFor="invite-password">Contraseña (opcional)</Label>
                    <Input
                      id="invite-password"
                      type="password"
                      placeholder="Dejar vacío para enviar email de invitación"
                      value={newUser.password}
                      onChange={(e) =>
                        setNewUser({ ...newUser, password: e.target.value })
                      }
                    />
                    <p className="text-xs text-muted-foreground">
                      Si estableces una contraseña, el usuario podrá iniciar sesión inmediatamente sin recibir email.
                    </p>
                  </div>
                  <Button
                    variant="accent"
                    className="mt-2"
                    onClick={handleInviteUser}
                    disabled={inviting}
                  >
                    {inviting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Crear Usuario
                  </Button>
                </div>
              )}
            </DialogContent>
          </Dialog>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar por nombre o email..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select
            value={roleFilter}
            onValueChange={(value: "all" | "admin" | "user") => setRoleFilter(value)}
          >
            <SelectTrigger className="w-full sm:w-[180px]">
              <SelectValue placeholder="Filtrar por rol" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos los roles</SelectItem>
              <SelectItem value="admin">Administradores</SelectItem>
              <SelectItem value="user">Vendedores</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Users Table */}
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : users.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground mb-4">
              No hay usuarios registrados. Invita al primer usuario.
            </p>
          </div>
        ) : (
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Usuario</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Rol</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead className="text-right">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users
                  .filter((user) => {
                    const matchesSearch =
                      searchQuery === "" ||
                      (user.name?.toLowerCase().includes(searchQuery.toLowerCase()) ?? false) ||
                      user.email.toLowerCase().includes(searchQuery.toLowerCase());
                    const matchesRole =
                      roleFilter === "all" || user.role === roleFilter;
                    return matchesSearch && matchesRole;
                  })
                  .map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-accent/10 text-accent">
                            {user.role === "admin" ? (
                              <Shield className="h-4 w-4" />
                            ) : (
                              <User className="h-4 w-4" />
                            )}
                          </div>
                          <span className="font-medium">
                            {user.name || user.email.split("@")[0]}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {user.email}
                      </TableCell>
                      <TableCell>
                        <Badge variant={user.role === "admin" ? "default" : "secondary"}>
                          {user.role === "admin" ? "Administrador" : "Vendedor"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {user.isActive ? (
                          <Badge variant="outline" className="text-green-600 border-green-600 bg-green-50">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Activo
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="text-amber-600 border-amber-600 bg-amber-50">
                            <Clock className="h-3 w-3 mr-1" />
                            Pendiente
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          {!user.isActive && (
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-amber-600 hover:text-amber-700 hover:bg-amber-50"
                              onClick={() => handleResendInvitation(user)}
                              disabled={resendingInvitation === user.id}
                              title="Reenviar invitación"
                            >
                              {resendingInvitation === user.id ? (
                                <Loader2 className="h-4 w-4 animate-spin" />
                              ) : (
                                <RefreshCw className="h-4 w-4" />
                              )}
                            </Button>
                          )}
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                            onClick={() => handleOpenSetPassword(user)}
                            title="Establecer contraseña"
                          >
                            <Key className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => handleOpenEdit(user)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-destructive hover:text-destructive"
                            onClick={() => {
                              setUserToDelete(user);
                              setIsDeleteOpen(true);
                            }}
                            disabled={user.id === currentUser?.id}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
            {users.filter((user) => {
              const matchesSearch =
                searchQuery === "" ||
                (user.name?.toLowerCase().includes(searchQuery.toLowerCase()) ?? false) ||
                user.email.toLowerCase().includes(searchQuery.toLowerCase());
              const matchesRole =
                roleFilter === "all" || user.role === roleFilter;
              return matchesSearch && matchesRole;
            }).length === 0 && (
              <div className="text-center py-8">
                <p className="text-muted-foreground">
                  No se encontraron usuarios con los filtros seleccionados.
                </p>
              </div>
            )}
          </Card>
        )}

        {/* Edit User Dialog */}
        <Dialog open={isEditOpen} onOpenChange={(open) => {
          setIsEditOpen(open);
          if (!open) resetEditForm();
        }}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Editar Usuario</DialogTitle>
              <DialogDescription>
                Modifica la información del usuario.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">Nombre Completo</Label>
                <Input
                  id="edit-name"
                  placeholder="Nombre del usuario"
                  value={editData.name}
                  onChange={(e) =>
                    setEditData({ ...editData, name: e.target.value })
                  }
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-email">Correo Electrónico</Label>
                <Input
                  id="edit-email"
                  type="email"
                  placeholder="correo@empresa.com"
                  value={editData.email}
                  onChange={(e) =>
                    setEditData({ ...editData, email: e.target.value })
                  }
                />
              </div>
              <div className="space-y-2">
                <Label>Rol del Usuario</Label>
                <Select
                  value={editData.role}
                  onValueChange={(value: "admin" | "user") =>
                    setEditData({ ...editData, role: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="user">Vendedor</SelectItem>
                    <SelectItem value="admin">Administrador</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button
                variant="accent"
                className="mt-2"
                onClick={handleUpdateUser}
                disabled={updating}
              >
                {updating && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Guardar Cambios
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation Dialog */}
        <AlertDialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>¿Eliminar usuario?</AlertDialogTitle>
              <AlertDialogDescription>
                Esta acción no se puede deshacer. Se eliminará el usuario{" "}
                <strong>{userToDelete?.name || userToDelete?.email}</strong> del sistema.
                {userToDelete?.sellerId && (
                  <span className="block mt-2 text-destructive">
                    También se eliminará su registro de vendedor y todos los datos relacionados (comisiones y pagos).
                  </span>
                )}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel onClick={() => setUserToDelete(null)}>
                Cancelar
              </AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDeleteUser}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                disabled={deleting}
              >
                {deleting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Eliminar
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* Set Password Dialog */}
        <Dialog open={isPasswordOpen} onOpenChange={(open) => {
          setIsPasswordOpen(open);
          if (!open) resetPasswordForm();
        }}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Establecer Contraseña</DialogTitle>
              <DialogDescription>
                Establece una nueva contraseña para{" "}
                <strong>{userToSetPassword?.name || userToSetPassword?.email}</strong>.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="new-password">Nueva Contraseña</Label>
                <Input
                  id="new-password"
                  type="password"
                  placeholder="Mínimo 6 caracteres"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                />
                <p className="text-xs text-muted-foreground">
                  El usuario podrá iniciar sesión inmediatamente con esta contraseña.
                </p>
              </div>
              <Button
                variant="accent"
                className="mt-2"
                onClick={handleSetPassword}
                disabled={settingPassword}
              >
                {settingPassword && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Guardar Contraseña
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
